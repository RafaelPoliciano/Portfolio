// ===================================
// MENU MOBILE TOGGLE
// ===================================
const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');

menuToggle.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

// Fechar menu ao clicar em um link
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
    });
});

// ===================================
// SMOOTH SCROLL
// ===================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ===================================
// HIGHLIGHT ACTIVE NAV LINK ON SCROLL
// ===================================
window.addEventListener('scroll', () => {
    let current = '';
    const sections = document.querySelectorAll('section');
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (scrollY >= (sectionTop - 200)) {
            current = section.getAttribute('id');
        }
    });

    document.querySelectorAll('.nav-links a').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// ===================================
// FORMULÁRIO DE CONTATO
// ===================================

// Função para validar email
function validarEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

// Função para validar formulário
function validarFormulario(dados) {
    const erros = [];

    if (!dados.nome || dados.nome.trim().length < 3) {
        erros.push('Nome deve ter pelo menos 3 caracteres');
    }

    if (!dados.email || !validarEmail(dados.email)) {
        erros.push('Email inválido');
    }

    if (!dados.assunto || dados.assunto.trim().length < 3) {
        erros.push('Assunto deve ter pelo menos 3 caracteres');
    }

    if (!dados.mensagem || dados.mensagem.trim().length < 10) {
        erros.push('Mensagem deve ter pelo menos 10 caracteres');
    }

    return erros;
}

// Função para exibir mensagem de resposta
function exibirMensagem(tipo, texto) {
    const responseDiv = document.getElementById('formResponse');
    responseDiv.style.display = 'block';
    
    if (tipo === 'sucesso') {
        responseDiv.style.color = '#4ade80';
        responseDiv.innerHTML = `✓ ${texto}`;
    } else {
        responseDiv.style.color = '#ef4444';
        responseDiv.innerHTML = `✕ ${texto}`;
    }
    
    // Esconder mensagem após 5 segundos
    setTimeout(() => {
        responseDiv.style.display = 'none';
    }, 5000);
}

// Função para enviar dados ao backend
async function enviarParaBancoDados(dados) {
    try {
        // URL completa - ajuste conforme sua estrutura
        const response = await fetch('http://localhost/portfolio/php/salvar_contato.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        });

        // Log para debug
        console.log('Status da resposta:', response.status);

        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const resultado = await response.json();
        console.log('Resposta do servidor:', resultado);
        return resultado;

    } catch (error) {
        console.error('Erro ao enviar para o banco:', error);
        throw error;
    }
}

// Handler do formulário de contato
document.getElementById('contactForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    // Desabilitar botão durante o envio
    const submitBtn = this.querySelector('.submit-btn');
    const btnTextoOriginal = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Enviando...';
    
    // Coletar dados do formulário
    const formData = {
        nome: document.getElementById('nome').value.trim(),
        email: document.getElementById('email').value.trim(),
        assunto: document.getElementById('assunto').value.trim(),
        mensagem: document.getElementById('mensagem').value.trim(),
        data: new Date().toISOString(),
        ip: '', // Será preenchido pelo backend
        userAgent: navigator.userAgent
    };

    // Validar dados
    const erros = validarFormulario(formData);
    
    if (erros.length > 0) {
        exibirMensagem('erro', erros.join(', '));
        submitBtn.disabled = false;
        submitBtn.textContent = btnTextoOriginal;
        return;
    }

    try {
        // Tentar enviar para o banco de dados
        const resultado = await enviarParaBancoDados(formData);
        
        if (resultado.sucesso) {
            exibirMensagem('sucesso', 'Mensagem enviada com sucesso! Em breve entrarei em contato.');
            this.reset(); // Limpar formulário
        } else {
            exibirMensagem('erro', resultado.mensagem || 'Erro ao enviar mensagem');
        }

    } catch (error) {
        // Se houver erro na conexão, salvar localmente e avisar
        console.log('Dados do formulário (salvos localmente):', formData);
        
        // Salvar no localStorage como backup
        salvarLocalmenteBackup(formData);
        
        exibirMensagem('sucesso', 'Mensagem registrada! (Modo de desenvolvimento)');
        this.reset();
    }
    
    // Reabilitar botão
    submitBtn.disabled = false;
    submitBtn.textContent = btnTextoOriginal;
});

// Função para salvar backup local (desenvolvimento)
function salvarLocalmenteBackup(dados) {
    try {
        // Buscar mensagens existentes
        let mensagens = JSON.parse(localStorage.getItem('mensagens_contato')) || [];
        
        // Adicionar nova mensagem
        mensagens.push({
            ...dados,
            id: Date.now(),
            timestamp: new Date().toLocaleString('pt-BR')
        });
        
        // Salvar de volta
        localStorage.setItem('mensagens_contato', JSON.stringify(mensagens));
        
        console.log('Mensagem salva localmente:', dados);
        console.log('Total de mensagens:', mensagens.length);
    } catch (error) {
        console.error('Erro ao salvar localmente:', error);
    }
}

// Função para recuperar mensagens salvas localmente (para desenvolvimento)
function verMensagensLocais() {
    const mensagens = JSON.parse(localStorage.getItem('mensagens_contato')) || [];
    console.table(mensagens);
    return mensagens;
}

// Expor função globalmente para debug
window.verMensagensLocais = verMensagensLocais;

// ===================================
// ANIMAÇÃO DE ENTRADA PARA ELEMENTOS
// ===================================
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

document.querySelectorAll('.project-card, .skill-category, .tech-content').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'all 0.6s ease';
    observer.observe(el);
});

// ===================================
// EFEITO DE DIGITAÇÃO NO TÍTULO (OPCIONAL)
// ===================================
function efeitoDigitacao() {
    const titulo = document.querySelector('.hero h1');
    if (!titulo) return;
    
    const textoCompleto = titulo.textContent;
    titulo.textContent = '';
    titulo.style.opacity = '1';
    
    let i = 0;
    const velocidade = 100; // milissegundos por caractere
    
    function digitar() {
        if (i < textoCompleto.length) {
            titulo.textContent += textoCompleto.charAt(i);
            i++;
            setTimeout(digitar, velocidade);
        }
    }
    
    // Descomentar a linha abaixo para ativar o efeito de digitação
    // setTimeout(digitar, 500);
}

// Inicializar efeito de digitação quando a página carregar
// efeitoDigitacao();

// ===================================
// CONTADOR DE VISITANTES (OPCIONAL)
// ===================================
function contarVisita() {
    let visitas = localStorage.getItem('visitas_portfolio') || 0;
    visitas = parseInt(visitas) + 1;
    localStorage.setItem('visitas_portfolio', visitas);
    console.log(`Total de visitas: ${visitas}`);
}

contarVisita();

// ===================================
// MENSAGEM DE BOAS-VINDAS NO CONSOLE
// ===================================
console.log('%c🚀 Portfólio Rafael Policiano', 'color: #667eea; font-size: 20px; font-weight: bold;');
console.log('%c💻 Desenvolvido com HTML, CSS e JavaScript', 'color: #764ba2; font-size: 14px;');
console.log('%c📧 Entre em contato através do formulário!', 'color: #f093fb; font-size: 14px;');
console.log('%c\n🔍 Para ver mensagens salvas localmente, digite: verMensagensLocais()', 'color: #4ade80; font-size: 12px;');