<?php
// =======================================
// HABILITAR ERROS (REMOVER EM PRODUÇÃO)
// =======================================
error_reporting(E_ALL);
ini_set('display_errors', 1);

// =======================================
// CONFIGURAÇÕES DO BANCO DE DADOS
// =======================================
$host = "localhost";
$usuario = "root";
$senha = "";
$banco = "portfolio_contato";

// =======================================
// PERMITIR CORS (para desenvolvimento local)
// =======================================
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

// Tratar requisições OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// =======================================
// VERIFICAR SE É POST
// =======================================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["sucesso" => false, "mensagem" => "Método não permitido"]);
    exit;
}

// =======================================
// LER O JSON ENVIADO PELO JAVASCRIPT
// =======================================
$dadosJSON = file_get_contents("php://input");
$dados = json_decode($dadosJSON, true);

if (!$dados) {
    echo json_encode(["sucesso" => false, "mensagem" => "Nenhum dado recebido"]);
    exit;
}

// =======================================
// VALIDAR CAMPOS (lado do servidor)
// =======================================
if (
    empty($dados["nome"]) ||
    empty($dados["email"]) ||
    empty($dados["assunto"]) ||
    empty($dados["mensagem"])
) {
    echo json_encode(["sucesso" => false, "mensagem" => "Preencha todos os campos."]);
    exit;
}

// Validar email
if (!filter_var($dados["email"], FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["sucesso" => false, "mensagem" => "Email inválido."]);
    exit;
}

// =======================================
// CAPTURAR IP DO USUÁRIO
// =======================================
$ip = $_SERVER["REMOTE_ADDR"] ?? "desconhecido";

// =======================================
// CONECTAR AO BANCO
// =======================================
$con = new mysqli($host, $usuario, $senha, $banco);

if ($con->connect_error) {
    echo json_encode([
        "sucesso" => false, 
        "mensagem" => "Erro ao conectar ao banco de dados",
        "erro_tecnico" => $con->connect_error // Remover em produção
    ]);
    exit;
}

// Definir charset
$con->set_charset("utf8mb4");

// =======================================
// PREPARAR INSERT (contra SQL injection)
// =======================================
$stmt = $con->prepare("
    INSERT INTO mensagens_contato 
    (nome, email, assunto, mensagem, data_envio, ip, user_agent)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");

if (!$stmt) {
    echo json_encode([
        "sucesso" => false, 
        "mensagem" => "Erro ao preparar consulta",
        "erro_tecnico" => $con->error // Remover em produção
    ]);
    exit;
}

$stmt->bind_param(
    "sssssss",
    $dados["nome"],
    $dados["email"],
    $dados["assunto"],
    $dados["mensagem"],
    $dados["data"],
    $ip,
    $dados["userAgent"]
);

// =======================================
// EXECUTAR INSERT
// =======================================
if ($stmt->execute()) {
    echo json_encode([
        "sucesso" => true,
        "mensagem" => "Mensagem salva com sucesso!",
        "id" => $stmt->insert_id
    ]);
} else {
    echo json_encode([
        "sucesso" => false, 
        "mensagem" => "Erro ao salvar mensagem",
        "erro_tecnico" => $stmt->error // Remover em produção
    ]);
}

// =======================================
// FECHAR CONEXÃO
// =======================================
$stmt->close();
$con->close();
?>